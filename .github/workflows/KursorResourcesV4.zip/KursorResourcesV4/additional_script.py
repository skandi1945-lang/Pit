import subprocess

# Запускаем стандартный калькулятор Windows
subprocess.Popen("calc.exe")
